# Image Sequence Finder

This script searches a given directory for image sequence files and returns a string containing the list of sequences found. 

It searches for files with the following extensions: 
* exr
* jpeg
* jpg
* png
* tif
* tiff
* mov